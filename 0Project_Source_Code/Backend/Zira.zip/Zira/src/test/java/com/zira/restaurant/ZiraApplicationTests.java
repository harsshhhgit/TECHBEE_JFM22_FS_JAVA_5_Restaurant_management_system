package com.zira.restaurant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZiraApplicationTests {

	@Test
	void contextLoads() {
	}

}
